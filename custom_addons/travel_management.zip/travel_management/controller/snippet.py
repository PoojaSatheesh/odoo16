# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo.http import request, route, Controller


class BookingDetails(Controller):
    @route(['/booking_details'], type="json", auth="public", website=True, methods=['POST'])
    def all_bookings(self):
        booking_ids = request.env['travel.management'].search_read([], limit=10)
        print(".....", booking_ids)
        return booking_ids
