# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import models


class SaleOrder(models.Model):
    _inherit = "sale.order"

    def action_import_lines(self):
        return {
            'name': "Import Lines Wizard",
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'import.lines.wizard',
            'target': 'new',
            'context': {
                'order_id': self.id
            }
        }

