{
    'name': 'Session website',
    'version': '16.0.1.0.0',
    'depends': ['website'],
    'data': [
        'data/website_menu_data.xml',
        'views/website_templete.xml'
    ],
}